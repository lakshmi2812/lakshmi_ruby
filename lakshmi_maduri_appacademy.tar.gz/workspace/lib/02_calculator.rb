def add(a,b)
    #returns the sum of arguments a and b
    a+b
end

def subtract(a,b)
    #return the difference of the arguments (a-b)
    a-b
end

def sum(arr)
    #returns the sum of all elements of the array
    arr_sum = 0
    arr.each do |i|
        arr_sum = arr_sum + i
    end
    arr_sum
end

def multiply(*args)
    case args.size
    when 1
        #If the argument is an array, this function returns th product of elements of the array
        arr_multiply = 1
        args[0].each do |i|
            arr_multiply = arr_multiply * i
        end
    when 2
        #if the arguments are numbers, the function returns the product of the two numbers
        arr_multiply = args[0]*args[1]
    end
    arr_multiply
end

def power(a,b)
    #the result of a raised to power of b is returned 
    a**b
end

def factorial(n)
    #returns the factorial of a given number
    if n == 0
        fact = 0
    elsif n == 1
        fact = 1
    else
        fact = n*factorial(n-1)
    end
    fact
end