def echo(str)
    #returns the argument passed into the function
    str
end

def shout(str)
    #returns the uppercase version of the argument passed
    str = str.upcase
    str
end

def repeat(*args)
    #This function can take either one or two arguments
    output = ""
    case args.size
    when 1
        #if only one argument is given, it repeats the argument twice 
        output = "#{args[0]} "+"#{args[0]}"
    when 2
        #if two arguments are given, the 2nd argument indicates the no.oftimes the 1st argument is repeated
        output = "#{args[0]}" + " #{args[0]}"*(args[1]-1)
    end
    output
end

def start_of_word(word, num)
    #returns the first 'n' letters of the first argument, where 'n' is the second argument
    x = 0
    output = ""
    while x < num
       output = output.to_s + word[x].to_s
       x = x+1
    end
    return output
    
end

def first_word(str)
    #returns the first word of the given string
    str_split = str.split
    output = str_split[0]
    output
end

def titleize(str)
    #Returns the capitalized version of the given string
    str_arr = str.split
    x = 0
    final_str = ""
    new_arr = []
    while x < str_arr.length
        little = ['a', 'e', 'i', 'o', 'u', 't'].include? str_arr[x][0]
        if (little == false) or (x == 0)
            new_arr.push(str_arr[x].capitalize)
        else
            new_arr.push(str_arr[x])
        end
        x = x + 1
    end
    final_str = new_arr.join(' ')
    final_str
end