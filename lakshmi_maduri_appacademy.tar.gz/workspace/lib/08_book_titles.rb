class Book
    #Setter method for title
    #This method also capitalizes the title according to the rules specified and returns the title
    def title=(new_title)
        title_arr = new_title.split
        new_title_arr = []
        omit = ["a", "an", "the", "of", "or", "for", "is", "at", "and", "in"]
        x = 0
        while x < title_arr.length
            if x == 0
                new_title_arr.push(title_arr[x].capitalize)
            else
                if omit.include?title_arr[x]
                    new_title_arr.push(title_arr[x])
                else
                    new_title_arr.push(title_arr[x].capitalize)
                end
            end
            x+=1
        end
        new_title = new_title_arr.join(' ')
        @title = new_title
    end
    
    #Getter method for title
    def title
        @title
    end
end
