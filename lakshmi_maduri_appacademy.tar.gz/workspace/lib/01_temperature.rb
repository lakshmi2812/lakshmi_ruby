#converts given fahrenheit temperature to celsius
def ftoc(f)
    (((f-32)*5)/9)
end

#converts given celsius value to fahrenheit
def ctof(c)
    res = (((c*9)/5.0))+32
    return res
end