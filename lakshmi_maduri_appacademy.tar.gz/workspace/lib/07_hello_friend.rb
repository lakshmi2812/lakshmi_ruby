class Friend
    #A method that displays a greeting message to the user
    def greeting(who = nil)
        if who == nil
            "Hello!"
        else
            "Hello, #{who}!"
        end
    end
end
