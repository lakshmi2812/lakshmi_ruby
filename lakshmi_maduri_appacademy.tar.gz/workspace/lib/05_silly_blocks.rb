def reverser &block
    str = yield
    str_arr = str.split
    i = 0
    str_rev_arr = [] 
    while i < str_arr.length
        str_rev = ""
        x = str_arr[i].length - 1
        while x >= 0
            str_rev = str_rev + str_arr[i][x]
            x = x - 1
        end
        str_rev_arr.push(str_rev)
        i+=1
    end
    str_rev_final = str_rev_arr.join(' ')
    str_rev_final
end

def adder value=nil,&block
    num = yield
    if value == nil
        num+1
    else
        num+value
    end
end

#repeats(executes) the block the num_of_times
def repeater num_of_times=nil,&block
    if num_of_times == nil
        block_was_executed = yield
        return block_was_executed
    else
        num_of_times.times{
            yield
        }
    end
end

