#function that returns the time taken to run a block of code 
def measure(num=nil)
    counter = 0
    start_time = Time.now
    if num == nil
        yield
        end_time = Time.now
        elapsed_time = (end_time - start_time)
        elapsed_time
    else
        num.times do
            counter += 1
            yield
        end
        (Time.now-start_time)/counter.to_f
    end
end