class Dictionary
    
  attr_accessor :entries, :keywords
    
  def initialize
    @entries = {}
  end
    
  def add(opts = {})
    myhash = {}
    if opts.is_a?(Hash) == true
      @entries = @entries.merge(opts)
    else
      myhash.store(opts,nil)
      @entries = myhash
    end
    @keywords = @entries.keys.sort
  end
  
  def include?(keyword)
    if keyword == nil
      return nil
    elsif @entries.has_key?(keyword) == true
      return true
    else
      return false
    end
  end
  
  def find(word)
    dict = {}
    if (@entries.has_key?(word) == true)
      dict.store(word, @entries[word])
      return dict
    elsif
      @entries.keys.each do |x|
        if (/#{word}/).match(x)
          dict.store(x, @entries[x])
        end
      end
      return dict
    else
      return dict
    end
  end
  
  def printable
    str = ""
    @keywords.each do |x|
      str = str + "[#{x}] \"#{@entries[x]}\"\n"
    end
    str = str.chomp
    return str
  end
    
end
