class Temperature
    def initialize(opts = {})
      @temp = opts
    end
    
    def Temperature.from_celsius(temp)
      Temperature.new(:c=>temp)
    end
    
    def self.from_fahrenheit(temp)
      Temperature.new(:f=>temp)
    end
    
    def in_fahrenheit
      #returns the fahrenheit equivalent of the given temperature
      if @temp.has_key?(:f)
        to_f = @temp[:f]
        to_f
      else
        celsius = @temp[:c]
        to_f = (((celsius * 9)/5.0) + 32)
        to_f
      end
    end
    
    def in_celsius
      #returns the celsius equivalent value of the given temperature
      if @temp.has_key?(:c)
        to_c = @temp[:c]
      else
        farenheit = @temp[:f]
        to_c = (((farenheit - 32)*5)/9)
        to_c
      end
    end
end

class Celsius < Temperature
  def initialize(temp_celsius)
    @temp = {:c=>temp_celsius}
  end
end

class Fahrenheit < Temperature
  def initialize(temp_fahrenheit)
    @temp = {:f=>temp_fahrenheit}
  end
end
