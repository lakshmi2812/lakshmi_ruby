def translate(str)
    #takes in a string and returns its translated version in Pig Latin language 
    str_arr = str.split
    vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']
    final_res_arr = []
    i = 0
    #iterate through each word in the given string 'str'
    while i < str_arr.length
        current_word = str_arr[i]
        len = current_word.length
        x = 0
        #iterate through each character in the word
        while x < len
            starts_vowel = vowels.include? current_word[x]
            if starts_vowel
                if x == 0
                    res = current_word + "ay"
                    break
                elsif current_word[x] == "u"
                   if current_word[x-1] != "q"
                       res = current_word[x..(len-1)] + current_word[0..(x-1)] + "ay"
                       break
                   end
                else
                    res = current_word[x..(len-1)] + current_word[0..(x-1)] + "ay"
                    break
                end
            end
            x+=1
        end
        #to translate capitalized words
        if current_word.capitalize == current_word
            final_res_arr.push(res.capitalize)
        else
            final_res_arr.push(res)
        end
        i+=1
    end
    final_res = final_res_arr.join(' ')
    final_res
end