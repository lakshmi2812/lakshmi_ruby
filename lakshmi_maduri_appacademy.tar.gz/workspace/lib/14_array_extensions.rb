class Array
    #Extending the Array class by adding new methods
    def sum
        #returns sum of the elements of any array
        array_sum = 0
        if self == []
            array_sum = 0
        else
            self.each do |x|
                array_sum += x
            end
        end
        array_sum
    end
    
    def square
        #returns the squares of elements of the array. Original array remains unchanged
        array_square = []
        if self == []
            array_square = []
        else
            array_square = self.map{|x| x*x}
        end
        array_square
    end
    
    def square!
        #returns the squares of elements of the array and in the process, changes the original array
        self.map!{|x| x*x} # modifies original array
    end
end