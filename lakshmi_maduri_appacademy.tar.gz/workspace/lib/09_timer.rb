class Timer
    #Initialize instance variable @seconds to 0
    def initialize
        @seconds = 0 
    end
    
    #Setter method for instance variable @seconds
    def seconds=(secs)
        @seconds = secs
    end
    
    #returns the time in hrs:mins:sec format
    def time_string
        time = @seconds
        mins = 0#initialize mins to 0
        hrs = 0#initialize hrs to 0
        if time < 60
            sec = time
        elsif time >= 60 and time < 3600
            sec = time%60
            mins = (time/60)
        end
        if time >= 3600
            hrs = (time/3600)
            mins = (time - 3600)/60
            sec = (time - 3600)%60
        end
        sec_padded = padded(sec)
        mins_padded = padded(mins)
        hrs_padded = padded(hrs)
        new_time = "#{hrs_padded}:#{mins_padded}:#{sec_padded}"
        @seconds = new_time
        @seconds
    end
    
    #Helper method for padding zeroes
    def padded(time)
        time_padded = (time.to_s).rjust(2,"0")
        time_padded
    end
    
    #Getter method for @seconds
    def seconds
        @seconds
    end
end