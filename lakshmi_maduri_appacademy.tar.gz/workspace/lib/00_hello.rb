#says hello
def hello
    "Hello!"
end

#greets the user
def greet(name)
    "Hello, #{name}!"
end