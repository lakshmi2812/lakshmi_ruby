class RPNCalculator
    attr_accessor :stack, :value
    def initialize
        @stack = Array.new
        @value = 0
    end
    
    #This function pushes the item(x) onto stack(array)
    def push(x)
        @stack.push(x)
    end
    
    #This function pops the top two elements from the stack and returns their sum
    #It also pushes the sum back onto stack
    def plus
        if @stack.empty?
            raise Exception.new("calculator is empty")
        else
            b = @stack.pop
            a = @stack.pop
            @value = a+b
            @stack.push(value)
        end
        @value
    end
    
    #This function pops the top two elements from the stack and returns their difference
    #It also pushes the difference back onto stack
    def minus
        if @stack.empty?
            raise Exception.new("calculator is empty")
        else
            b = @stack.pop
            a = @stack.pop
            @value = a-b
            @stack.push(@value)
        end
        @value
    end
    
    #This function pops the top two elements of the stack and returns their product
    #It also pushes the product back onto the stack
    def times
        if @stack.empty?
            raise Exception.new("calculator is empty")
        else
            b = @stack.pop.to_f
            a = @stack.pop.to_f
            @value = a*b
            @stack.push(@value)
        end
        @value
    end
    
    #This function returns the quotient of the division of top two elements on the stack
    #It also pushes the quotient back onto the stack
    def divide
        if @stack.empty?
            raise Exception.new("calculator is empty")
        else
            b = @stack.pop.to_f
            a = @stack.pop.to_f
            @value = a/b
            @stack.push(@value)
        end
        @value
    end
    
    def tokens(str)
        str = str.delete(" ")
        token_arr = []
        operators = ["+", "-", "*", "/"]
        x = 0
        while x < str.size
            if operators.include?(str[x])
                new_arr = %I{#{str[x]}}
            else
                new_arr = Array(str[x].to_i)
            end
            token_arr = token_arr.concat(new_arr)
            x+=1
        end
        token_arr
    end
    
    #Evaluates the given string(str) according to RPN and returns the result
    def evaluate(str)
        str_arr = str.split(' ')
        str_arr.each do |x|
            if x == "+"
                puts "string of x is: #{x}"
                self.plus
            elsif x == "-"
                self.minus
            elsif x == "*"
                self.times
            elsif x == "/"
                self.divide
            elsif /[0-9]/.match(x)#if we encounter any digit between 0 and 9
                self.push(x.to_i)
            end
        end
        @value
    end
end
